<article>
    <header><h1>ExpressJS Server</h1></header>
    <main>
        <p>
            Simple OOP auto loading expressJS server.<br />
            Registers the views as endpoints and looks for their data interface in the ViewTemplates.ts file 
        </p>
    </main>
</article>

<article>
    <header><h2>Setup:</h2></header>
    <main>
    <ul>
        <li>clone repo</li>
        <li>npm run install</li>
        <li>npm run start</li>
    </ul>
    </main>
</article>

<article>
    <header><h2>Current functionality:</h2></header>
    <main>
        <ul>
            <li>HTTPServer singleton pattern</li>
            <li>Automated ExpressJS view loading</li>
            <li>POST/GET callback interface implementation</li>
        </ul>
    </main>
</article>

