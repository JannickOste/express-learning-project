import { IViewTemplateModel, IRequestCallback } from './IViewTemplateModel';
import { Request, Response, NextFunction } from 'express';

/**
 * Namespace containing IViewTemplates, used for registering views based on generic type attribute (T).
 * models must be made in IViewTemplates.ts otherwise they wont be detected, 
 * todo: look into universal solution..;
 */
export namespace ViewTemplates {
  type Wrapper < T > = {
    new(...args: any[]): T;

    readonly prototype: T;
  }

  const viewImplementations: Wrapper < IViewTemplateModel > [] = [];

  /**
   * Get all registered views using the set attribute 
   * 
   * @returns IViewTemplateModel array
   */
  export function getViews(): Wrapper < IViewTemplateModel > [] 
  {
    return viewImplementations;
  }

  /**
   * sets an interface object to the views template stack
   * 
   * @param ctor extended type of IViewTemplateModel
   * @returns IViewTemplateModel wrapper
   */
  export function set < T extends Wrapper < IViewTemplateModel >> (ctor: T) {
    viewImplementations.push(ctor);
    return ctor;
  }

  /**
 * Implementation of IViewTemplate interface in class style. 
 * 
 */
  @ViewTemplates.set
  class Index {
    public get: IRequestCallback = (req, res, next) => 
    {
      return {
        data: {}
      };
    }

    post = undefined
  }

    /**
   * Implementation of IViewTemplate interface in class style. 
   * 
   */
  @ViewTemplates.set
  class GetExample implements IViewTemplateModel {
    public get: IRequestCallback = (req, res, next) => 
    {
      const index: number = Number.parseInt(`${(req as any).query.index}`);

      return {
        data: 
        {
          person: isNaN(index) ?  "No person index defined" : [{name: "Jannick Oste"}, {name: "Tom Bom"}][index],
          index:  isNaN(index) ? -1 : index 
        }

      }
    }

    post = undefined
  } 


  @ViewTemplates.set
  class PostExample
  {
    public get: IRequestCallback = (req, res, next) => { return {
        data: {
          message: undefined 
        }
      }
    }

    public post: IRequestCallback = (req, res, next) => { 
      console.log("posting...");
      return {
        data: {
          message: `Welcome, ${(req.body as any).fname}` 
        }
      }
    }
  }
}
//#endregion

//#region Page objects


//#endregion