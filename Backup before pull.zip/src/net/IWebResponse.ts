
  export interface IWebResponse {
      data: object;
  }