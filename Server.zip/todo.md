# !TODO: 
- Add data sanitization 
- Add IWebRequest implementation for GET Requests.
- Add internal TPL Constructor.
