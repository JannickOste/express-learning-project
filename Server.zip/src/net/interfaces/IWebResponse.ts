/**
 * Data response interface for server reply
 */
export interface IWebResponse
{
    data: object;
}