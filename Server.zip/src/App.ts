import { WebServer } from "./net/WebServer";

WebServer.instance.start();

